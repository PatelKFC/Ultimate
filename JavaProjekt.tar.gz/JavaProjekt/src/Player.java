import java.awt.Point;


public class Player extends J
{
    public static boolean inCombat;
    public static boolean isPraying;
    public static boolean isLooting;

    public static boolean lowPrayer;
    public static boolean lowHealth;
    public static boolean isVenomed;

    public static boolean appliedCombat;

    public Player()
    {
        StartLoop(Player::Update, 10);
    }

    public static void SetCombat(boolean value)
    {
        appliedCombat = value;
    }

    public static void Update()
    {
        //isPraying = MonitorPoints.quickPrayersOn;
        inCombat = CombatHandler.inCombat;

        //Execute(Player::EnablePray, inCombat, !MonitorPoints.quickPrayersOn, !isPraying);
        //Execute(Player::DisablePray, !inCombat, MonitorPoints.quickPrayersOn, isPraying);
        //Execute(Inventory::SipRestore, lowPrayer);
    }

    public static boolean IsLowHealth()
    {
        var point = Prayer.prayerOrb;
        return ScreenUtils.HasColor("LowHealth", 25, point);
    }



}