
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class Prayer extends J
{
    public static final String prayOnPath = Resources("sprites/quick_prayer_on.png");
    public static final String prayOffPath= Resources("sprites/quick_prayer_off.png");
    public static final String antiMage = Resources("sprites/anti_mage.png");
    public static final String antiRange = Resources("sprites/anti_range.png");
    public static final String antiMelee = Resources("sprites/anti_melee.png");
    public static final String lowPrayerFolder = Resources("quick_prayers");

    public static BufferedImage prayOn, prayOff;

    public static boolean initialized, isLooping, isPraying, pietyOn, rigourOn, auguryOn;

    public static int detectionRadius = DynamicValues.GetValue("PRAYER_RADIUS");

    public static int xOffset = 300, yOffset = -50;

    public static int radius = 120;

    public static Point prayerOrb;



    public static void Init()
    {
        if(initialized) return;

        //KeyUtils.SubscribeKeyEvent(Prayer::Test, "E");

        GetPrayerOrb();
        try {

            prayOn = ImageIO.read(new File(prayOnPath));
            prayOff = ImageIO.read(new File(prayOffPath));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        initialized = true;


        Log("Prayer Initialized!");


    }

    public static boolean IsLowPrayer()
    {
        GetPrayerOrb();
        return ScreenUtils.HasColor("LowPrayer", 20, prayerOrb);
    }

    public static boolean IsPraying()
    {
        GetPrayerOrb();
        return ScreenUtils.HasColor("QuickPrayersOn", 20, prayerOrb);
    }

    public static void Test()
    {
        var point = ScreenUtils.GetCenterPoint("RuneWild");

        point.x += xOffset;
        point.y += yOffset;

        MouseUtils.MoveTo(point);
    }

    public static void PrayPiety()
    {
        Pray("piety");
    }


    public static void PrayRigour()
    {
        Pray("rigour");
    }


    public static void PrayAugury()
    {
        pietyOn = false;
        rigourOn = false;
        if(auguryOn) return;
        Pray("augury");
    }

    public static void EnableQuickPrayers()
    {
        if(prayOff == null || prayerOrb == null) return;
        var a = ScreenUtils.HasImage(prayOff, prayerOrb, detectionRadius);
        if(a)
        {
            //MouseUtils.SaveMousePos();
            MouseUtils.ClickAt(prayerOrb);
            Sleep(100);
            //MouseUtils.MoveMouseBack();
        }

    }

    public static void DisableQuickPrayers()
    {
        var a = ScreenUtils.HasImage(prayOn, prayerOrb, detectionRadius);
        if(a)
        {
            //MouseUtils.SaveMousePos();
            MouseUtils.ClickAt(prayerOrb);
            //MouseUtils.MoveMouseBack();
        }
    }

    public static void GetPrayerOrb()
    {
        var point = ScreenUtils.GetCenterPoint("RuneWild");

        if(point != null)
        {
            point.x += xOffset;
            point.y += yOffset;

            prayerOrb = point;

            Log("Prayer Orb Point Set!");
        }
    }

    public static void Pray(String prayer)
    {
        if(!initialized)
        {
            initialized = true;
            Init();
        }
        if(prayer.contains("auto_on"))
        {
            EnableQuickPrayers();
            return;
        }
        if(prayer.contains("auto_off"))
        {
            DisableQuickPrayers();
            return;
        }
        MouseUtils.SaveMousePos();
        KeyUtils.SendKey("F3");
        Sleep(30);
        ItemDef.ClickImage(prayer);
        KeyUtils.SendKey("F1");
        //Sleep(30);
        //MouseUtils.MoveMouseBack();
    }
}