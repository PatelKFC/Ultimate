import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class J
{
    public static String Resources(String path)
    {
        return System.getProperty("user.home") + "/Downloads/Resources/" + path;
    }

    public static void KeepAlive()
    {
        Thread t = new Thread(() -> {while(true){
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }});

        t.start();
    }

    public static void Sleep(long ms)
    {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static void StartLoop(Runnable method, long ms)
    {
        var t = new Thread(() ->
        {
            while(true)
            {
                method.run();
                try {
                    Thread.sleep(ms);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        } );

        t.start();
    }

    public static long Seconds(long amt)
    {
        return amt * 1000;
    }

    public static long Minutes(long amt)
    {
        return amt * (1000 * 60);
    }

    public static String R(String s)
    {
        return s.replaceAll("\\s+","");
    }

    public static boolean ToBool(String value)
    {
        return value.contains("True") || value.contains("true");
    }

    public static void Log(Object o)
    {
        System.out.println(o);
    }

    public static void Execute(Runnable method, Boolean... conditions)
    {
        boolean canExecute = true;

        if(conditions.length > 0) {
            for (boolean a : conditions) {
                if (!a) {
                    canExecute = false;
                    return;
                }
            }

        }
        if(canExecute)
        {
            method.run();
        }
    }

    public static void DisableNativeLogs()
    {
        Logger logger = Logger.getLogger("org.jnativehook");
        logger.setLevel(Level.OFF);
        for (Handler handler : logger.getHandlers()) {
            handler.setLevel(Level.OFF);
        }

    }

}
