public class ColorEntity
{
    public String identifier;
    public String[] colors;

    public ColorEntity(String id, String[] array)
    {
        this.identifier = id;
        this.colors = array;
    }
}
