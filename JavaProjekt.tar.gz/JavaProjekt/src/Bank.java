public class Bank
{
    public static void OpenBank()
    {

    }
}
