import java.awt.Point;

public class Minimap
{
    public static Point GetMinimap()
    {
        var p = ScreenUtils.GetCenterPoint("RuneWild");

        p.x += 400;
        p.y -= 80;

        return p;
    }
    public static Point GetCompass()
    {
        var p = ScreenUtils.GetCenterPoint("RuneWild");

        p.x += 295;
        p.y -= 140;

        return p;
    }
    public static Point GetPrayerOrb()
    {
        var p = ScreenUtils.GetCenterPoint("RuneWild");

        p.x += 300;
        p.y -= 50;

        return p;
    }
    public static Point GetHealthOrb()
    {
        var p = ScreenUtils.GetCenterPoint("RuneWild");

        p.x += 300;
        p.y -= 100;

        return p;
    }
    public static Point GetRunOrb()
    {
        var p = ScreenUtils.GetCenterPoint("RuneWild");

        p.x += 300;
        p.y -= 30;

        return p;
    }
}