import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

import java.awt.image.BufferedImage;

public class OCRHandler {
    public static String performOCR(BufferedImage image) {
        Tesseract tesseract = new Tesseract();
        tesseract.setDatapath("path/to/tessdata"); // Set the path to the tessdata folder
        tesseract.setLanguage("eng"); // Set the language

        try {
            return tesseract.doOCR(image);
        } catch (TesseractException e) {
            e.printStackTrace();
            return null;
        }
    }
}
