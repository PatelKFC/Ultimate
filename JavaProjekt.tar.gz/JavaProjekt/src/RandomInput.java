import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Random;


public class RandomInput extends J
{

    private static final int HOLD_TIME_MIN = 500; // Minimum hold time in milliseconds
    private static final int HOLD_TIME_MAX = 1000; // Maximum hold time in milliseconds
    private static final int KEY_PRESS_INTERVAL_MIN = 1000; // Minimum interval before the next key press
    private static final int KEY_PRESS_INTERVAL_MAX = 3000; // Maximum interval before the next key press

    private static final int[] KEYS = {
            //KeyEvent.VK_UP,    // Up
            // KeyEvent.VK_DOWN,  // Down
            KeyEvent.VK_LEFT,  // Left
            KeyEvent.VK_RIGHT  // Right
    };

    private static Robot robot;
    private static Random random;

    private static boolean initialized;

    public static boolean enabled = true;

    public static void Init()
    {
        if(initialized) return;

        try {
            robot = new Robot();
            random = new Random();
            startRandomInput();
        } catch (AWTException e) {
            e.printStackTrace();
        }

        System.out.println("Initializing Random Keys...");
    }

    public static void Enable()
    {
        Execute(() -> { enabled = true;});
    }

    public static void Disable()
    {
        Execute(() -> { enabled = false; }, initialized);
    }

    public static void startRandomInput() {
        if(initialized) return;
        new Thread(() -> {
            while (true) {
                if(enabled && !GoldLooter.paused) {
                    int keyToPress = KEYS[random.nextInt(KEYS.length)];
                    holdKey(keyToPress);
                    try {
                        Thread.sleep(random.nextInt(KEY_PRESS_INTERVAL_MAX - KEY_PRESS_INTERVAL_MIN) + KEY_PRESS_INTERVAL_MIN);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    private static void holdKey(int key) {
        robot.keyPress(key); // Press the key down
        int holdTime = random.nextInt(HOLD_TIME_MAX - HOLD_TIME_MIN) + HOLD_TIME_MIN;
        try {
            Thread.sleep(holdTime); // Hold the key for a random duration
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        robot.keyRelease(key); // Release the key
    }


}