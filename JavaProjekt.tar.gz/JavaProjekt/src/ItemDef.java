import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

public class ItemDef extends J
{
    public static final String folder = Resources("Images/");
    public static final String data = Resources("Data/ItemDef/");

    public static List<BufferedImage> itemIDs = new ArrayList<>();
    public static List<String> itemNames = new ArrayList<>();

    public static int radius = 100;

    private static boolean initialized;

    public static void Init()
    {
        if(initialized) return;
        GetItems();
    }

    public static void GetItems()
    {
        initialized = true;
        processClasses();
    }


    public static void processClasses() {
        File[] rawClasses = getClasses();
        for (File file : rawClasses) {
            ReadContent(file);
        }
    }

    public static File[] getClasses() {
        File dataFolder = new File(data);
        return dataFolder.listFiles(File::isFile);
    }


    public static void ReadContent(File file) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null)
            {
                var itemName = line;
                BufferedImage targetImage = ImageIO.read(new File(Resources("Images/" + itemName+ ".png")));


                //Log("Added Item Definition: " + itemName);

                if(targetImage != null)
                {
                    //Log("We Have Target Image");


                    itemIDs.add(targetImage);
                    itemNames.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static BufferedImage GetItem(String identifier)
    {
        Init();
        for(int i = 0; i < itemNames.size(); i++)
        {
            if(itemNames.get(i).contains(identifier))
            {
                return itemIDs.get(i);
            }
        }

        return null;
    }

    public static BufferedImage GetImage(String id)
    {
        BufferedImage image = null;
        try {
            image = ImageIO.read(new File(Resources("Images/") + id + ".png"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return image;
    }



    public static void ClickImage(String img)
    {/*
		var raw = GetItem(img);

		//if(Inventory.inventory == null)return;

//		var point = ScreenUtils.ImagePoint(raw, CClicker.position, radius);

		if(point != null)
		{
			//Log("We Have A Point!");
			MouseUtils.ClickAt(point);
		}

		if(point == null)
		{
			//Log("No Point!");
		}*/
    }
}