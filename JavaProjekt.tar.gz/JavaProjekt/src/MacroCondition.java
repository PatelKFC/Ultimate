public class MacroCondition extends J
{
    public String args, bool, value;

    public boolean condition;

    public MacroCondition(String args)
    {
        this.args = args;
        Filter(args);
    }

    private void Filter(String args)
    {
        Execute(() -> SetColor(args), args.contains("Color"));
        Execute(() -> SetBoolean(args), Main.HasVariable(args));
    }

    private void SetColor(String args)
    {
        var color = R(args.split("::")[1]);
        var b = ScreenUtils.HasColor(color, DynamicValues.GetValue("RADIUS"));
        condition = b;
    }

    private void SetBoolean(String args)
    {
        this.condition = Main.GetBoolean(args);
    }

    public boolean IsTrue()
    {
        SetColor(args);
        var two = ToBool(value);

        return condition == two;
    }
}
