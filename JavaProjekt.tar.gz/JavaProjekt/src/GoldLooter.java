public class GoldLooter extends J
{
    public static boolean paused;
    public static void main(String[] args)
    {
        DynamicValues.Init();
        KeyUtils.Init();
        MouseUtils.Init();
        RandomInput.Init();

        StartLoop(GoldLooter::Loot, DynamicValues.GetValue("LOOP_TIME"));
        KeyUtils.SubscribeKeyEvent(() -> paused = !paused, "F");
    }

    public static void Loot()
    {
        if(paused) return;
        ScreenUtils.PixelClick("Coins");
    }
}
