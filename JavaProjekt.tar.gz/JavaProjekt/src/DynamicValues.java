import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class DynamicValues extends J {
    public static final String filePath = Resources("Data/DynamicValues.txt"); // Adjust as necessary
    public static final String colorPath = Resources("Data/ColorIDs.txt");
    public static List<String> identifiers = new ArrayList<>();
    public static List<Integer> values = new ArrayList<>();
    public static List<Double> doubles = new ArrayList<>();
    public static List<ColorEntity> colors = new ArrayList<>();

    public static List<String> lines = new ArrayList<>();

    public static String GetRaw(String id)
    {
        for(String s : lines)
        {
            if(s.contains(id))
            {
                return R(s.split("::")[1]);
            }
        }

        return "";
    }

    public static int GetValue(String identifier) {
        for (int i = 0; i < identifiers.size(); i++) {
            if (identifiers.get(i).contains(identifier)) {
                return values.get(i);
            }
        }
        return 100; // Default value if not found
    }

    public static double GetDoubleValue(String identifier) {
        for (int i = 0; i < identifiers.size(); i++) {
            if (identifiers.get(i).contains(identifier)) {
                return doubles.get(i);
            }
        }
        return 100; // Default value if not found
    }

    public static ColorEntity GetColor(String identifier) {
        for (int i = 0; i < colors.size(); i++) {
            if (colors.get(i).identifier.contains(identifier)) {
                return colors.get(i);
            }
        }
        return null; // Default color if not found (white)
    }

    public static void Init() {
        // Initialize int values from DynamicValues.txt
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
                String[] parts = line.split("::");
                if (!line.contains(".") && parts.length == 2) {
                    String identifier_ = parts[0].trim();
                    int value = Integer.parseInt(parts[1].trim());
                    identifiers.add(identifier_);
                    values.add(value);
                    //Log(identifier_ + " " + value);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        // Initialize color values from ColorIDs.txt
        try (BufferedReader br = new BufferedReader(new FileReader(colorPath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("::");
                if (parts.length == 2) {
                    String colorIdentifier = parts[0].trim();
                    var array = parts[1].split(",");


                    ColorEntity color = new ColorEntity(colorIdentifier, array);
                    colors.add(color);

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}