import java.awt.Point;
import java.awt.image.BufferedImage;

public class Inventory extends J {


    public static int xOffset = 390;         // Horizontal offset between slots
    public static int yOffset = 160;         // Vertical offset between rows

    public static int radius = DynamicValues.GetValue("INVENTORY_RADIUS");

    public static Point inventory;

    public static BufferedImage restoreImage;

    public static boolean gearing, geared;

    public static void Init()
    {
        GetPoint();
    }

    public static boolean NoFood()
    {
        GetPoint();
        var a = !ScreenUtils.HasEntity("Shark", inventory);

        return a;
    }

    public static void DrinkRestore()
    {
        GetPoint();
        Log("Drink");
        ClickItem("super_restore");
    }

    public static void ClickItem2(BufferedImage img)
    {
        //GetPoint();

        if(img != null)
        {
            var a = ScreenUtils.HasImage(img, inventory, radius);
            if(!a)
            {
                Log("We Do Not Have It!");
            }
            if(a)
            {
                var b = ScreenUtils.ImagePoint(img, inventory, radius);
                Log("We Have It!");
                MouseUtils.MoveTo(b);
            }
        }
    }

    public static void ClickItem(String obj)
    {
        var img = ItemDef.GetImage(obj);

        if(img != null)
        {


            var b = ScreenUtils.ImagePoint(img, inventory, radius);
            Log("We Have It!");
            MouseUtils.ClickAt(b);
            if(b == null) return;
            //MouseUtils.MoveTo(b);
        }

    }

    public static void GetPoint()
    {
        var point = ScreenUtils.GetCenterPoint("RuneWild");

        point.x += xOffset;
        point.y += yOffset;

        inventory = point;
    }

    public static void Test()
    {
        //GetPoint();

        ClickItem2(restoreImage);
    }
}