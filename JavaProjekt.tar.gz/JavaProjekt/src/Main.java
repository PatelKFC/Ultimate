import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Main extends J
{
    public static File[] files = new File(Resources("Scripts")).listFiles();

    public static List<MacroClass> macroClasses = new ArrayList<>();


    private static String className;

    public static boolean HasVariable(String args)
    {
        for(var a : macroClasses)
        {
            for(var b : a.boolNames)
            {
                if(args.contains(b))
                {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean GetBoolean(String args)
    {
        for(var a : macroClasses)
        {
            for(int i = 0; i < a.boolNames.size(); i++)
            {
                if(args.contains(a.boolNames.get(i)))
                {
                    return a.booleans.get(i);
                }
            }
        }

        return false;
    }

    public static void SetBoolean(String args)
    {
        for(var a : macroClasses)
        {
            for(int i = 0; i < a.boolNames.size(); i++)
            {
                if(args.contains(a.boolNames.get(i)))
                {
                   if(args.contains("True") || args.contains("true"))
                   {
                       a.booleans.set(i, true);
                   }
                    if(args.contains("False") || args.contains("false"))
                    {
                        a.booleans.set(i, false);
                    }
                }
            }
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
        KeepAlive();
        for(var file : files) {
            className = file.getName();
            Log(className);
            Scanner scanner = new Scanner(file);
            List<String> content = new ArrayList<>();

            while (scanner.hasNextLine()) {
                var line = scanner.nextLine();
                content.add(line);
            }


            var a = new MacroClass(className, content);
            macroClasses.add(a);
        }
        }
    }
