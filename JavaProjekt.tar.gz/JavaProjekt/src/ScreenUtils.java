import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class ScreenUtils extends J {
    public static int xOffset = -140;
    public static int yOffset = -140;
    public static String windowTitle = "RuneWild";
    private static BufferedImage[] targetImages;



    public static void ClickOnNPC(String test)
    {
        // Initialize the images from the specified folder
        String npcFolderPath = test;
        ScreenUtils.initializeImages(npcFolderPath);

        // Define a base point where you want to search for NPCs
        Point basePoint = ScreenUtils.GetCenterPoint("RuneWild"); // Get the center of the RuneWild window
        int searchRadius = DynamicValues.GetValue("SEARCH_RADIUS"); // Define the search radius

        // Check if an NPC is present and click on it if found
        if (ScreenUtils.HasObject(basePoint, searchRadius)) {
            Point clickPoint = ScreenUtils.ObjectPoint(basePoint, searchRadius);
            if (clickPoint != null) {
                // Click on the found object

                MouseUtils.ClickAt(clickPoint);
                //GUIHelper.SetEntityPoint(clickPoint);

                //MouseUtils.MoveTo(clickPoint);
                // System.out.println("Clicked on the object at: " + clickPoint);
            }
        }

    }

    public static void PixelClick(String identifier, Point... pt)
    {
        identifier = R(identifier);
        //Log("Attempting... " + identifier);

        var point = ScreenUtils.GetCenterPoint("RuneWild");

        if(pt.length > 0)
        {
            point = pt[0];
        }
        ColorEntity colorEntity = DynamicValues.GetColor(identifier);
        if(colorEntity == null)
        {
            Log("This Is Null!");
            return;
        }
        for(var s : colorEntity.colors) {
            var pixelPoint = ScreenUtils.GetColorPoint(s, point, DynamicValues.GetValue("SEARCH_RADIUS"));

            if (pixelPoint != null) {
                Log("We Have A Point!");
                MouseUtils.ClickAt(pixelPoint);
                break;
            }
        }
    }

    public static boolean HasColorFixed(String id, Point... pt)
    {
        int radius = DynamicValues.GetValue("SEARCH_RADIUS");
        //Log("Attempting...");
        var point = ScreenUtils.GetCenterPoint("RuneWild");
        if(pt.length > 0)
        {
            point = pt[0];
        }
        var color = DynamicValues.GetColor(id);

        for(String s : color.colors) {
            var pixelPoint = ScreenUtils.GetColorPoint(s, point, radius);

            if (pixelPoint != null) {
                return true;
            }
        }

        return false;
    }


    public static boolean HasColor(String id, int radius, Point... pt)
    {
        //Log("Attempting...");
        var point = ScreenUtils.GetCenterPoint("RuneWild");
        if(pt.length > 0)
        {
            point = pt[0];
        }
        var color = DynamicValues.GetColor(id);

        for(String s : color.colors) {
            var pixelPoint = ScreenUtils.GetColorPoint(s, point, radius);

            if (pixelPoint != null) {
                return true;
            }
        }

        return false;
    }


    public static Point EntityPoint(String info)
    {
        // Initialize the images from the specified folder
        String npcFolderPath = info;
        ScreenUtils.initializeImages(npcFolderPath);

        // Define a base point where you want to search for NPCs
        Point basePoint = ScreenUtils.GetCenterPoint("RuneWild"); // Get the center of the RuneWild window
        int searchRadius = DynamicValues.GetValue("SEARCH_RADIUS");// Define the search radius

        // Check if an NPC is present and click on it if found
        if (ScreenUtils.HasObject(basePoint, searchRadius)) {
            Point clickPoint = ScreenUtils.ObjectPoint(basePoint, searchRadius);
            if (clickPoint != null)
            {
                // Click on the found object
                return clickPoint;

            }
        }

        return null;
    }


    public static boolean HasHealthBar(String test, Point... p)
    {

        // Initialize the images from the specified folder
        String npcFolderPath = test; // Change this to your actual image folder path
        ScreenUtils.initializeImages(npcFolderPath);
        if(targetImages == null) return false;
        if(targetImages.length <= 0) return false;
        // Define a base point where you want to search for NPCs
        Point basePoint = ScreenUtils.GetCenterPoint("RuneWild"); // Get the center of the RuneWild window
        if(p.length > 0)
        {
            basePoint = p[0];
        }
        if(basePoint == null) return false;
        int searchRadius = DynamicValues.GetValue("LOCAL_SEARCH_RADIUS");; // Define the search radius

        // Check if an NPC is present and click on it if found
        if (ScreenUtils.HasObject(basePoint, searchRadius)) {
            Point clickPoint = ScreenUtils.ObjectPoint(basePoint, searchRadius);
            if (clickPoint != null) {
                // Click on the found object
                //MouseUtils.ClickAt(clickPoint);
                return true;
                //MouseUtils.MoveTo(clickPoint);
                //System.out.println("Clicked on the object at: " + clickPoint);
            }
        }
        return false;
    }

    public static boolean HasEntity(String test, Point... pt)
    {

        // Initialize the images from the specified folder
        String npcFolderPath = test; // Change this to your actual image folder path
        ScreenUtils.initializeImages(npcFolderPath);
        if(targetImages == null) return false;
        if(targetImages.length <= 0) return false;
        // Define a base point where you want to search for NPCs
        Point basePoint = ScreenUtils.GetCenterPoint("RuneWild"); // Get the center of the RuneWild window
        if(pt.length > 0)
        {
            basePoint = pt[0];
        }
        if(basePoint == null) return false;
        int searchRadius = DynamicValues.GetValue("SEARCH_RADIUS"); // Define the search radius

        // Check if an NPC is present and click on it if found
        if (ScreenUtils.HasObject(basePoint, searchRadius)) {

            // Click on the found object
            //MouseUtils.ClickAt(clickPoint);
            return true;
            //MouseUtils.MoveTo(clickPoint);
            //System.out.println("Clicked on the object at: " + clickPoint);
        }

        return false;
    }

    public static void initializeImages(String folderPath) {
        File folder = new File(folderPath);
        if(folder == null) return;
        File[] imageFiles = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".png"));
        if (imageFiles != null) {
            targetImages = new BufferedImage[imageFiles.length];
            for (int i = 0; i < imageFiles.length; i++) {
                try {
                    targetImages[i] = ImageIO.read(imageFiles[i]);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void ClickObject(Point basePoint, int radius) {
        var a = ObjectPoint(basePoint, radius);
        if (a != null) {
            MouseUtils.ClickAt(a);
        }
    }

    public static Point ObjectPoint(Point basePoint, int radius) {
        try {
            Robot robot = new Robot();
            int searchAreaX = Math.max(0, basePoint.x - radius);
            int searchAreaY = Math.max(0, basePoint.y - radius);
            int searchAreaWidth = Math.min(radius * 2, Toolkit.getDefaultToolkit().getScreenSize().width - searchAreaX);
            int searchAreaHeight = Math.min(radius * 2, Toolkit.getDefaultToolkit().getScreenSize().height - searchAreaY);

            Rectangle searchRect = new Rectangle(searchAreaX, searchAreaY, searchAreaWidth, searchAreaHeight);
            BufferedImage searchAreaImage = robot.createScreenCapture(searchRect);

            for (BufferedImage targetImage : targetImages) {
                if(targetImage == null) return null;
                Point matchPoint = findImage(searchAreaImage, targetImage, searchAreaX, searchAreaY);
                if (matchPoint != null) {
                    return matchPoint;
                }
            }
        } catch (AWTException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean HasObject(Point basePoint, int radius) {
        if (basePoint == null) return false;
        return ObjectPoint(basePoint, radius) != null;
    }

    public static boolean HasImage(BufferedImage targetImage, Point point, int radius) {
        try {
            Robot robot = new Robot();
            int searchAreaX = Math.max(0, point.x - radius);
            int searchAreaY = Math.max(0, point.y - radius);
            int searchAreaWidth = Math.min(radius * 2, Toolkit.getDefaultToolkit().getScreenSize().width - searchAreaX);
            int searchAreaHeight = Math.min(radius * 2, Toolkit.getDefaultToolkit().getScreenSize().height - searchAreaY);

            Rectangle searchRect = new Rectangle(searchAreaX, searchAreaY, searchAreaWidth, searchAreaHeight);
            BufferedImage searchAreaImage = robot.createScreenCapture(searchRect);
            if(searchAreaImage == null) return false;
            return findImage(searchAreaImage, targetImage, searchAreaX, searchAreaY) != null;
        } catch (AWTException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static Point ImagePoint(BufferedImage targetImage, Point point, int radius) {
        try {
            Robot robot = new Robot();
            int searchAreaX = Math.max(0, point.x - radius);
            int searchAreaY = Math.max(0, point.y - radius);
            int searchAreaWidth = Math.min(radius * 2, Toolkit.getDefaultToolkit().getScreenSize().width - searchAreaX);
            int searchAreaHeight = Math.min(radius * 2, Toolkit.getDefaultToolkit().getScreenSize().height - searchAreaY);

            Rectangle searchRect = new Rectangle(searchAreaX, searchAreaY, searchAreaWidth, searchAreaHeight);
            BufferedImage searchAreaImage = robot.createScreenCapture(searchRect);
            return findImage(searchAreaImage, targetImage, searchAreaX, searchAreaY);
        } catch (AWTException e) {
            e.printStackTrace();
        }
        return null;
    }


    private static Point findImage(BufferedImage screenImage, BufferedImage targetImage, int offsetX, int offsetY) {
        for (int x = 0; x <= screenImage.getWidth() - targetImage.getWidth(); x++) {
            for (int y = 0; y <= screenImage.getHeight() - targetImage.getHeight(); y++) {
                boolean match = true;

                for (int tx = 0; tx < targetImage.getWidth(); tx++) {
                    for (int ty = 0; ty < targetImage.getHeight(); ty++) {
                        if (screenImage.getRGB(x + tx, y + ty) != targetImage.getRGB(tx, ty)) {
                            match = false;
                            break;
                        }
                    }
                    if (!match) {
                        break;
                    }
                }

                if (match) {
                    return new Point(x + offsetX, y + offsetY);
                }
            }
        }
        return null;
    }

    public static Point GetPoint(int xOffset_, int yOffset_) {
        var point = GetCenterPoint(windowTitle);
        point.x += xOffset_;
        point.y += yOffset_;
        return point;
    }


    private BufferedImage image;


    public static Point GetColorPoint(String colorCode, Point basePoint, int radius) {
        try {
            // Convert colorCode (hex) to Color object
            Color targetColor = Color.decode(colorCode);

            // Create a Robot instance to capture the screen
            Robot robot = new Robot();

            // Define the rectangle area to capture
            int startX = Math.max(basePoint.x - radius, 0);
            int startY = Math.max(basePoint.y - radius, 0);
            int endX = Math.min(basePoint.x + radius, (int) java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth() - 1);
            int endY = Math.min(basePoint.y + radius, (int) java.awt.Toolkit.getDefaultToolkit().getScreenSize().getHeight() - 1);

            // Capture the screen in the defined area
            BufferedImage screenCapture = robot.createScreenCapture(new Rectangle(startX, startY, endX - startX + 1, endY - startY + 1));

            // Search within the captured area
            for (int y = 0; y < screenCapture.getHeight(); y++) {
                for (int x = 0; x < screenCapture.getWidth(); x++) {
                    Color pixelColor = new Color(screenCapture.getRGB(x, y));

                    // Check if the current pixel matches the target color
                    if (pixelColor.equals(targetColor)) {
                        // Return the found point relative to the screen
                        return new Point(startX + x, startY + y); // Adjust for the area captured
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions (e.g., AWT exceptions)
        }

        return null;
    }


    public static Point GetCenterPoint(String windowTitle) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("bash", "-c", "wmctrl -l | grep \"" + windowTitle + "\"");
            Process process = processBuilder.start();

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line = reader.readLine();
                if (line != null) {
                    String[] parts = line.trim().split("\\s+");
                    String windowId = parts[0];

                    processBuilder = new ProcessBuilder("bash", "-c", "xdotool getwindowgeometry --shell " + windowId);
                    process = processBuilder.start();

                    try (BufferedReader geometryReader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                        int x = 0, y = 0, width = 0, height = 0;

                        while ((line = geometryReader.readLine()) != null) {
                            if (line.startsWith("X=")) x = Integer.parseInt(line.split("=")[1]);
                            else if (line.startsWith("Y=")) y = Integer.parseInt(line.split("=")[1]);
                            else if (line.startsWith("WIDTH=")) width = Integer.parseInt(line.split("=")[1]);
                            else if (line.startsWith("HEIGHT=")) height = Integer.parseInt(line.split("=")[1]);
                        }

                        return new Point(x + (width / 2) + xOffset, y + (height / 2) + yOffset);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Point(0, 0); // Return (0, 0) on error
    }

    public static void moveMouseTo(int x, int y) {
        try {
            String command = String.format("xdotool mousemove %d %d", x, y);
            Runtime.getRuntime().exec(new String[]{"bash", "-c", command});
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}