import javax.swing.*;

public class Area extends J
{
    public static void Init()
    {
       // StartLoop(Area::Loop, 100);
    }

    private static boolean NoArea()
    {
        return !ScreenUtils.HasColor("Home", DynamicValues.GetValue("RADIUS")) || !ScreenUtils.HasColor("WaterfallCave", DynamicValues.GetValue("RADIUS"));
    }

    public static boolean IsHome()
    {
        return ScreenUtils.HasColor("Home", DynamicValues.GetValue("RADIUS"));
    }
    public static boolean IsWaterfallCave()
    {
        return ScreenUtils.HasColor("WaterfallCave", DynamicValues.GetValue("RADIUS"));
    }
    private static void Loop()
    {
        Execute(() -> FireGiantKiller.areaValue.setText("Home"), IsHome());
        Execute(() -> FireGiantKiller.areaValue.setText("Waterfall Cave"), IsWaterfallCave());
        Execute(() -> FireGiantKiller.areaValue.setText("None"), NoArea());
        }
    }

