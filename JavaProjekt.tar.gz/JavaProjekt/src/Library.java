import java.awt.*;

public class Library extends J
{
    public static void GearUp()
    {
        KeyUtils.SendKey("F7");
        Sleep(1000);
        MouseUtils.ClickAt(GetLoadoutsPoint());
        Sleep(1000);
        KeyUtils.SendKey("F7");
        Sleep(1000);

        Log("Gear Up Cycle Complete!");

    }

    public static Point GetInventoryPoint()
    {
        var point = ScreenUtils.GetCenterPoint("RuneWild");

        point.x += 390;
        point.y += 160;

        return point;
    }

    public static Point GetLoadoutsPoint()
    {
        Point p = ScreenUtils.GetCenterPoint("RuneWild");
        p.x += DynamicValues.GetValue("LOADOUTS_X");
        p.y += DynamicValues.GetValue("LOADOUTS_Y");

        return p;
    }
}
