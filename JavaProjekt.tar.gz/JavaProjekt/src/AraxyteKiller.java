import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class AraxyteKiller extends J
{
    public static JPanel panel;
    public static JLabel areaLabel, areaValue;

    public static boolean walkedToDoor, inCombat, attacked, hasTarget, praying, lowPrayer, hasLoot, paused = false, restart, canFuck = false, pauseInput;

    //steps

    public static boolean walkToTree = true, clickOnTree;

    public static long rangePotionLoop = Minutes(3);

    public static void main(String[] args)
    {
        DisableNativeLogs();
        DynamicValues.Init();
        MouseUtils.Init();
        KeyUtils.Init();
        //Area.Init();
        //RandomInput.Init();

       /* JFrame frame = new JFrame("Debug");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Set size of the frame
        frame.setSize(400, 300);
        panel = new JPanel();

        frame.add(panel);

        areaLabel = new JLabel("Area: ");
        areaLabel.setBounds(20, 20, 30, 10);

        areaValue = new JLabel("None");
        areaValue.setBounds(50, 20, 30, 10);

        panel.add(areaLabel);
        panel.add(areaValue);

        frame.setVisible(true);

        */
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::RotateCamera, "I");
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::Teleport, "U");
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::GearUp, "Q");
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::Track, "E");
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::Agility, "W");
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::TraverseTwo, "R");
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::TrackTwo, "T");
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::TrackThree, "Y");
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::Exit, "ESC");

        var p = ScreenUtils.GetCenterPoint("RuneWild");
        p.x += 400;
        p.y += 180;
        KeyUtils.SubscribeKeyEvent(() -> paused = !paused, "F");
        //StartLoop(FireGiantKiller::AutoPray, 100);
        StartLoop(AraxyteKiller::Update, 100);
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::RouteThreeOne, "V");
        KeyUtils.SubscribeKeyEvent(AraxyteKiller::RouteThreeTwo, "C");
        StartLoop(AraxyteKiller::RangingPotionLoop, rangePotionLoop);
    }

    public static void RouteTest()
    {
        var point = Minimap.GetMinimap();
        point.x -= DynamicValues.GetValue("ARAXYTE_CAVE_X_3");
        point.y -= DynamicValues.GetValue("ARAXYTE_CAVE_Y_3");

        MouseUtils.ClickAt(point);
    }

    public static void RouteTest2()
    {
        var point = Minimap.GetMinimap();
        point.x -= DynamicValues.GetValue("ARAXYTE_CAVE_X_4");
        point.y -= DynamicValues.GetValue("ARAXYTE_CAVE_Y_4");

        MouseUtils.ClickAt(point);
    }

    public static void RouteThreeOne()
    {
        var point = Minimap.GetMinimap();
        point.x -= DynamicValues.GetValue("ARAXYTE_CAVE_X_3_3");
        point.y -= DynamicValues.GetValue("ARAXYTE_CAVE_Y_3_3");

        MouseUtils.MoveTo(point);
    }

    public static void RouteThreeTwo()
    {
        var point = Minimap.GetMinimap();
        point.x -= DynamicValues.GetValue("ARAXYTE_CAVE_X_4_3");
        point.y -= DynamicValues.GetValue("ARAXYTE_CAVE_Y_4_3");

        MouseUtils.MoveTo(point);
    }

    public static void RangingPotionLoop()
    {
        if(ScreenUtils.HasColorFixed("RangingPotion", Library.GetInventoryPoint()))
        {
            ScreenUtils.PixelClick("RangingPotion", Library.GetInventoryPoint());
            Log("Has Ranging Potion! Attempting To Drink...");
        }
    }

    public static void Teleport()
    {
        if(ScreenUtils.HasColorFixed("HouseTablet", Library.GetInventoryPoint()))
        {
            canFuck = false;
            inCombat = false;
            lowPrayer = false;
            praying = false;
            hasLoot = false;
            attacked = false;
            walkToTree = true;
            ScreenUtils.PixelClick("HouseTablet", Library.GetInventoryPoint());
            Log("Has House Tablet! Attempting To Teleport...");
            Sleep(Seconds(5));
            canFuck = false;
            inCombat = false;
            lowPrayer = false;
            praying = false;
            hasLoot = false;
            attacked = false;
            walkToTree = true;
            GearUp();
        }
    }

    public static boolean NoSupplies()
    {
        return !ScreenUtils.HasColorFixed("SuperRestore", Library.GetInventoryPoint());
    }

    public static void RotateCamera()
    {
        KeyUtils.HoldKeyDownFor(KeyEvent.VK_RIGHT, Seconds(1));
    }

    public static void RotateCameraLeft()
    {
        KeyUtils.HoldKeyDownFor(KeyEvent.VK_LEFT, Seconds(1));
    }

    public static void GearUp()
    {
        MouseUtils.ClickAt(Minimap.GetCompass());
        Sleep(250);
        Library.GearUp();
        Sleep(600);
        ScreenUtils.PixelClick("QuickPrayersOff", Minimap.GetPrayerOrb());
        Sleep(400);
        AutoWalk();
        Sleep(Seconds(4));
        KeyUtils.SendKey("F1");
        Sleep(150);
        Track();
        Sleep(Seconds(6));
        Agility();
        Sleep(Seconds(5));
        Traverse();
        Sleep(Seconds(3));
        TrackTwo();
        Sleep(Seconds(5));
        TrackThree();
        Sleep(Seconds(5));


        RotateCamera();
        canFuck = true;

        Log("Its fuckin time!");

    }

    public static void Track()
    {
        var point = Minimap.GetMinimap();

        point.x -= DynamicValues.GetValue("ARAXYTE_CAVE_X_0");
        point.y -= DynamicValues.GetValue("ARAXYTE_CAVE_Y_0");

        MouseUtils.ClickAt(point);
    }

    public static void TrackTwo()
    {
        var point = Minimap.GetMinimap();

        point.x -= DynamicValues.GetValue("ARAXYTE_CAVE_X_1");
        point.y -= DynamicValues.GetValue("ARAXYTE_CAVE_Y_1");

        MouseUtils.ClickAt(point);
    }

    public static void TrackThree()
    {
        var point = Minimap.GetMinimap();

        point.x -= DynamicValues.GetValue("ARAXYTE_CAVE_X_2");
        point.y -= DynamicValues.GetValue("ARAXYTE_CAVE_Y_2");

        MouseUtils.ClickAt(point);
    }



    public static void Agility()
    {
        if(ScreenUtils.HasColorFixed("AGILITY_SHORTCUT", Minimap.GetMinimap()))
        {
            ScreenUtils.PixelClick("AGILITY_SHORTCUT", Minimap.GetMinimap());
            Log("Has Agility Shortcut Icon!");
        }
    }

    public static void Traverse()
    {
        if(ScreenUtils.HasColorFixed("WEB_TUNNEL"))
        {
            ScreenUtils.PixelClick("WEB_TUNNEL");
            Log("Has Web Tunnel Shortcut!");
        }
    }

    public static void TraverseTwo()
    {
        if(ScreenUtils.HasColorFixed("SECOND_WEB_TUNEL"))
        {
            ScreenUtils.PixelClick("SECOND_WEB_TUNEL");
            Log("Has Web Tunnel Shortcut!");
        }
    }

    public static Point GetInventoryPoint()
    {
        var p = ScreenUtils.GetCenterPoint("RuneWild");
        p.x += 400;
        p.y += 180;

        return p;
    }

    public static Point GetHealthbarPoint()
    {
        var p = ScreenUtils.GetCenterPoint("RuneWild");
        p.x -= 240;
        p.y -= 110;
        return p;
    }

    public static void Update()
    {
        if(paused || !canFuck) return;
        AutoLoot();
        AutoKill();
        AutoDrink();
        AutoTeleport();
        //AutoAntiVenom();
       // AutoWalk();
    }

    public static void AutoTeleport()
    {
        if(NoSupplies() && canFuck)
        {
            Log("No Supplies! Regearing...");
            Teleport();
        }
    }

    public static void AutoWalk()
    {
        if(walkToTree)
        {
            MouseUtils.ClickAt(Minimap.GetCompass());
            Sleep(150);
            ScreenUtils.PixelClick("TELEPORT_ICON", Minimap.GetMinimap());
            walkToTree = false;

            Sleep(2600);

            while(!ScreenUtils.HasColor("MENU_ORANGE", DynamicValues.GetValue("RADIUS")))
            {
                Log("Waiting For Menu To Open...");

            ScreenUtils.PixelClick("GrandTree");
            Sleep(800);
            }

            if(!ScreenUtils.HasColor("MENU_ORANGE", DynamicValues.GetValue("RADIUS")))
            {
                ScreenUtils.PixelClick("GrandTree");
                Sleep(800);
            }
            Sleep(800);
            ScreenUtils.PixelClick("MENU_HEART");
            Sleep(800);

            var point = ScreenUtils.GetCenterPoint("RuneWild");

            point.y -= DynamicValues.GetValue("Y_OFFSET");

            MouseUtils.ClickAt(point);
        }
    }

    public static void AutoDrink()
    {
        lowPrayer = ScreenUtils.HasColor("LowPrayer", DynamicValues.GetValue("PRAYER_RADIUS"), Minimap.GetPrayerOrb());
        boolean hasRestore = ScreenUtils.HasColor("SuperRestore", DynamicValues.GetValue("INVENTORY_RADIUS"), GetInventoryPoint());
        if(lowPrayer && hasRestore)
        {
            ScreenUtils.PixelClick("SuperRestore", GetInventoryPoint());
            Log("Low Prayer! Attempting To Drink Super Restore...");

            Sleep(150);
        }
    }

    public static void AutoAntiVenom()
    {
        boolean isVenomed = ScreenUtils.HasColor("IsVenomed", DynamicValues.GetValue("SEARCH_RADIUS"), Minimap.GetHealthOrb());
        boolean hasAntiVenom = ScreenUtils.HasColor("AntiVenom", DynamicValues.GetValue("INVENTORY_RADIUS"), GetInventoryPoint());
        if(isVenomed && hasAntiVenom)
        {
            ScreenUtils.PixelClick("AntiVenom", GetInventoryPoint());
            Log("Is Venomed! Attempting To Drink Anti-Venom...");

            Sleep(150);
        }
    }

    public static void AutoKill()
    {
        if(hasTarget && !hasLoot)
        {
            ScreenUtils.PixelClick("Araxyte");
            Sleep(150);
        }
        inCombat = ScreenUtils.HasColor("Healthbar", DynamicValues.GetValue("PRAYER_RADIUS"), GetHealthbarPoint());
        hasTarget = ScreenUtils.HasColor("Araxyte", DynamicValues.GetValue("SEARCH_RADIUS"));
    }

    public static void AutoLoot()
    {
        hasLoot = ScreenUtils.HasColor("Coins", DynamicValues.GetValue("SEARCH_RADIUS"));

        if(hasLoot)
        {
            ScreenUtils.PixelClick("Coins");
            Sleep(150);

            Log("Has Loot!");
            inCombat = false;
        }
    }

    public static void AutoPray()
    {
        inCombat = ScreenUtils.HasColor("Healthbar", DynamicValues.GetValue("PRAYER_RADIUS"), GetHealthbarPoint());
        boolean hasPrayOff = ScreenUtils.HasColor("QuickPrayersOff", DynamicValues.GetValue("PRAYER_RADIUS"), Minimap.GetPrayerOrb());
        boolean hasPrayOn = ScreenUtils.HasColor("QuickPrayersOn", DynamicValues.GetValue("PRAYER_RADIUS"), Minimap.GetPrayerOrb());
        if(inCombat && hasPrayOff)
        {
            MouseUtils.SaveMousePos();
            ScreenUtils.PixelClick("QuickPrayersOff", Minimap.GetPrayerOrb());
            praying = true;
            MouseUtils.MoveMouseBack();
            Log("Praying!");
        }
        /*if(!inCombat && hasPrayOn)
        {
            MouseUtils.SaveMousePos();
            ScreenUtils.PixelClick("QuickPrayersOn", Minimap.GetPrayerOrb());
            praying = false;
            Log("Not Praying!");
            MouseUtils.MoveMouseBack();
        }*/
    }

    public static void Exit()
    {
        System.exit(0);
    }

    public static void Process()
    {
        ScreenUtils.PixelClick("WaterfallDoor", Minimap.GetMinimap());
    }

    public static void Test()
    {
        ScreenUtils.PixelClick("WaterfallDoor");
    }
}
