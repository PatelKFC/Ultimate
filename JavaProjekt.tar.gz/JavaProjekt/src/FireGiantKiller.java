import javax.swing.*;
import java.awt.*;

public class FireGiantKiller extends J
{
    public static JPanel panel;
    public static JLabel areaLabel, areaValue;

    public static boolean walkedToDoor, inCombat, attacked, hasTarget, praying, lowPrayer, hasLoot, paused, pauseInput;

    public static void main(String[] args)
    {
        DisableNativeLogs();
        DynamicValues.Init();
        MouseUtils.Init();
        KeyUtils.Init();
        Area.Init();
        RandomInput.Init();

       /* JFrame frame = new JFrame("Debug");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Set size of the frame
        frame.setSize(400, 300);
        panel = new JPanel();

        frame.add(panel);

        areaLabel = new JLabel("Area: ");
        areaLabel.setBounds(20, 20, 30, 10);

        areaValue = new JLabel("None");
        areaValue.setBounds(50, 20, 30, 10);

        panel.add(areaLabel);
        panel.add(areaValue);

        frame.setVisible(true);

        */
        KeyUtils.SubscribeKeyEvent(FireGiantKiller::Process, "Q");
        KeyUtils.SubscribeKeyEvent(FireGiantKiller::Test, "E");
        KeyUtils.SubscribeKeyEvent(FireGiantKiller::Exit, "ESC");

        var p = ScreenUtils.GetCenterPoint("RuneWild");
        p.x += 400;
        p.y += 180;
        KeyUtils.SubscribeKeyEvent(() -> paused = !paused, "F");
        //StartLoop(FireGiantKiller::AutoPray, 100);
        StartLoop(FireGiantKiller::Update, 100);
    }

    public static Point GetInventoryPoint()
    {
        var p = ScreenUtils.GetCenterPoint("RuneWild");
        p.x += 400;
        p.y += 180;

        return p;
    }

    public static Point GetHealthbarPoint()
    {
        var p = ScreenUtils.GetCenterPoint("RuneWild");
        p.x -= 240;
        p.y -= 110;
        return p;
    }

    public static void Update()
    {
        if(paused) return;
        AutoLoot();
        AutoKill();
        AutoDrink();
    }

    public static void AutoDrink()
    {
        lowPrayer = ScreenUtils.HasColor("LowPrayer", DynamicValues.GetValue("PRAYER_RADIUS"), Minimap.GetPrayerOrb());
        boolean hasRestore = ScreenUtils.HasColor("SuperRestore", DynamicValues.GetValue("INVENTORY_RADIUS"), GetInventoryPoint());
        if(lowPrayer && hasRestore)
        {
            ScreenUtils.PixelClick("SuperRestore", GetInventoryPoint());
            Log("Low Prayer! Attempting To Drink Super Restore...");

            Sleep(150);
        }
    }

    public static void AutoKill()
    {
        if(hasTarget && !hasLoot)
        {
            ScreenUtils.PixelClick("Araxyte");
            Sleep(150);
        }
        inCombat = ScreenUtils.HasColor("Healthbar", DynamicValues.GetValue("PRAYER_RADIUS"), GetHealthbarPoint());
        hasTarget = ScreenUtils.HasColor("Araxyte", DynamicValues.GetValue("SEARCH_RADIUS"));
    }

    public static void AutoLoot()
    {
        hasLoot = ScreenUtils.HasColor("Coins", DynamicValues.GetValue("SEARCH_RADIUS"));

        if(hasLoot)
        {
            ScreenUtils.PixelClick("Coins");
            Sleep(150);

            Log("Has Loot!");
            inCombat = false;
        }
    }

    public static void AutoPray()
    {
        inCombat = ScreenUtils.HasColor("Healthbar", DynamicValues.GetValue("PRAYER_RADIUS"), GetHealthbarPoint());
        boolean hasPrayOff = ScreenUtils.HasColor("QuickPrayersOff", DynamicValues.GetValue("PRAYER_RADIUS"), Minimap.GetPrayerOrb());
        boolean hasPrayOn = ScreenUtils.HasColor("QuickPrayersOn", DynamicValues.GetValue("PRAYER_RADIUS"), Minimap.GetPrayerOrb());
        if(inCombat && hasPrayOff)
        {
            MouseUtils.SaveMousePos();
            ScreenUtils.PixelClick("QuickPrayersOff", Minimap.GetPrayerOrb());
            praying = true;
            MouseUtils.MoveMouseBack();
            Log("Praying!");
        }
        /*if(!inCombat && hasPrayOn)
        {
            MouseUtils.SaveMousePos();
            ScreenUtils.PixelClick("QuickPrayersOn", Minimap.GetPrayerOrb());
            praying = false;
            Log("Not Praying!");
            MouseUtils.MoveMouseBack();
        }*/
    }

    public static void Exit()
    {
        System.exit(0);
    }

    public static void Process()
    {
        ScreenUtils.PixelClick("WaterfallDoor", Minimap.GetMinimap());
    }

    public static void Test()
    {
        ScreenUtils.PixelClick("WaterfallDoor");
    }
}
