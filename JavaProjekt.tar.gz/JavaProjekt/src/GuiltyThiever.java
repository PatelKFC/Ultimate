import java.awt.*;
import java.awt.event.KeyEvent;

public class GuiltyThiever extends J
{
    public static Robot robot;
    public static boolean paused, banking;
    public static long second = 1000;
    public static long bankLoopTime = second * 35;

    public static boolean init = false;
    public static void main(String[] args)
    {
        try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }
        DynamicValues.Init();
        KeyUtils.Init();
        MouseUtils.Init();

        ///StartLoop(GuiltyThiever::Update, 20);
        //StartLoop(GuiltyThiever::BankLoop, bankLoopTime);
        KeyUtils.SubscribeKeyEvent(() -> paused = !paused, "F");
        //KeyUtils.SubscribeKeyEvent(GuiltyThiever::Exit, "ESC");
        KeyUtils.SubscribeKeyEvent(GuiltyThiever::Bank,"E");
    }

    public static void Exit()
    {
        System.exit(0);
    }

    public static void BankLoop()
    {

        boolean canRun = false;
        if(init)
        {
            canRun = true;
        }
        if(!init)
        {
            init = true;
            return;
        }

        Execute(GuiltyThiever::Bank, canRun);
    }

    public static void Bank()
    {
        banking = true;
        Sleep(second * 10);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);

        robot.keyPress(KeyEvent.VK_SHIFT);
        robot.keyPress(KeyEvent.VK_COLON);
        robot.keyRelease(KeyEvent.VK_COLON);

        robot.keyPress(KeyEvent.VK_COLON);
        robot.keyRelease(KeyEvent.VK_COLON);

        robot.keyRelease(KeyEvent.VK_SHIFT);

        robot.keyPress(KeyEvent.VK_B);
        robot.keyRelease(KeyEvent.VK_B);
        robot.keyPress(KeyEvent.VK_A);
        robot.keyRelease(KeyEvent.VK_A);
        robot.keyPress(KeyEvent.VK_N);
        robot.keyRelease(KeyEvent.VK_N);
        robot.keyPress(KeyEvent.VK_K);
        robot.keyRelease(KeyEvent.VK_K);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);

        Sleep(1000);

        Point p = ScreenUtils.GetCenterPoint("RuneWild");
        p.x += 200;
        p.y += 200;

        while(!ScreenUtils.HasColor("BANK_INVENTORY_ICON", DynamicValues.GetValue("BANK_RADIUS"), p))
        {
            Log("Waiting For Bank...");
        }
        Log("Bank Loaded! Attempting To Deposit Inventory...");
        ScreenUtils.PixelClick("BANK_INVENTORY_ICON", p);

        Sleep(500);
        robot.keyPress(KeyEvent.VK_ESCAPE);
        robot.keyRelease(KeyEvent.VK_ESCAPE);
        Log("Banking Cycle Complete!");
        banking = false;
    }

    public static void Update()
    {
        if(paused || banking) return;
        boolean hasItem = ScreenUtils.HasColor("SilkStall", DynamicValues.GetValue("THIEVING_RADIUS"));

        if(hasItem)
        {
            ScreenUtils.PixelClick("SilkStall");
            Log("Has Silk! Attempting To Steal It...");
        }
    }
}
