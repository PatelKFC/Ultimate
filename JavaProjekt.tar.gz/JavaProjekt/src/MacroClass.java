import java.io.File;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class MacroClass extends J
{
    public String className;
    public List<String> lines = new ArrayList<>();
    public List<String> boolNames = new ArrayList<>();
    public List<Boolean> booleans = new ArrayList<>();

    public List<MacroCondition> macroConditions = new ArrayList<>();
    public List<Runnable> steps = new ArrayList<>();

    public MacroClass(String name, List<String> list) {
        this.className = name;
        this.lines = list;

        Log("MACRO CLASS CREATED!");

        Build();

        StartLoop(this::Execute, DynamicValues.GetValue("LOOP_TIME"));
    }


    public void Execute()
    {
        Execute(() ->
        {
            for(var a : steps)
            {
                a.run();
            }
        }, CanExecute());
    }

    private boolean CanExecute()
    {
        for(var a : macroConditions)
        {
            if(!a.IsTrue())
            {
                return false;
            }
        }

        return true;
    }

    void Build()
    {
        for(int i = 0; i < lines.size(); i++)
        {
            Process(lines.get(i), i);
        }
    }

    void Process(String line, int index)
    {
        Execute(() -> ProcessBoolean(line, index), line.contains("Bool") || line.contains("bool"));
        Execute(() -> ProcessMethod(line, index), line.contains("\\("));
        Execute(() -> addLogRunnable(line), line.contains("Log"));
    }


    void addLogRunnable(String line)
    {
        var toLog = line.split(",")[1];

        Log(toLog);
    }

    void ProcessBoolean(String line, int index)
    {
        var array = line.split("::");
        var name = R(array[1]);
        boolean bool = false;
        boolNames.add(name);
        booleans.add(bool);
    }

    void ProcessMethod(String line, int index)
    {
        var args = line.split(",");

        for(var a : args)
        {
            MacroCondition b = new MacroCondition(a);
            macroConditions.add(b);
        }
    }
}
