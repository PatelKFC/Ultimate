import java.awt.AWTException;
import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.InputEvent;

public class MouseUtils extends J {
    public static Point lastPoint;
    public static Robot robot;

    public static void Init() {
        Execute(() -> {
            try {
                robot = new Robot();
            } catch (AWTException e) {
                e.printStackTrace();
            }
        }, robot == null);
    }

    public MouseUtils() {
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public static void SaveMousePos() {
        Point originalPosition = java.awt.MouseInfo.getPointerInfo().getLocation();
        lastPoint = originalPosition;
    }

    public static Color GetPixelColor(int x, int y) {
        Rectangle screenBounds = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        if (!screenBounds.contains(x, y)) {
            return Color.BLACK; // Return a default color for out-of-bounds
        }
        return robot.getPixelColor(x, y);
    }

    public static Point MousePosition() {
        return java.awt.MouseInfo.getPointerInfo().getLocation();
    }

    public static void SetNewCoords() {
        var point = java.awt.MouseInfo.getPointerInfo().getLocation();
    }

    public static void MoveTo(int x, int y) {
        robot.mouseMove(x, y);
    }

    public static void MoveTo(Point point) {
        if (point == null) return;
        robot.mouseMove(point.x, point.y);
    }

    public static void ClickAt(Point point) {
        if (point == null) return;
        MoveTo(point);
        Sleep(50);
        Click();
        Sleep(20);
    }

    public static void Click() {
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); // Mouse down
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); // Mouse up
    }

    public static void MoveMouseBack(Boolean... booleans) {
        if (lastPoint == null) return;
        if (booleans.length <= 0) {
            Sleep(2);
            robot.mouseMove(lastPoint.x, lastPoint.y);
        }
        if (booleans.length > 0) {
            robot.mouseMove(lastPoint.x, lastPoint.y);
            Sleep(20);
            Click();
        }
    }

    // Scroll up (in)
    public static void ScrollIn(int notches, int delayMillis) {
        for (int i = 0; i < notches; i++) {
            robot.mouseWheel(-1); // Scroll up
            Sleep(delayMillis); // Wait between scrolls
        }
    }

    // Scroll down (out)
    public static void ScrollOut(int notches, int delayMillis) {
        for (int i = 0; i < notches; i++) {
            robot.mouseWheel(1); // Scroll down
            Sleep(delayMillis); // Wait between scrolls
        }
    }
}