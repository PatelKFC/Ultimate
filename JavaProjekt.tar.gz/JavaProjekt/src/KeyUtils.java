import java.awt.AWTException;
import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.SwingUtilities;

import org.jnativehook.GlobalScreen;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;


public class KeyUtils extends J implements NativeKeyListener {

    public static List<Integer> inputs = new ArrayList<>();
    public static List<Runnable> processes = new ArrayList<>();
    public static List<String> scriptKeys = new ArrayList<>();
    public static List<String> scripts = new ArrayList<>();

    public static Robot robot;

    private static boolean initialized;

    public static boolean keyPressed = false;
    public static int lastPressed = -1;

    public static void main(String[] args)
    {
        Init();
    }

    public static void Init() {
        try {
            if(initialized) return;
            KeyUtils keyUtils = new KeyUtils();
            DisableNativeLogs();
            robot = new Robot();

            initialized = true;
            try {
                GlobalScreen.registerNativeHook();
            } catch (Exception e) {
                e.printStackTrace();
            }

            GlobalScreen.addNativeKeyListener(keyUtils);
            //coroutine = StartCoroutine(KeyUtils::Loop, "Input");
            //coroutine.Stop();

            // keyUtils.coroutine = coroutine;

        } catch (AWTException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    public static boolean Pressed(String key)
    {
        if(lastPressed > 0 && lastPressed == GetKeyEvent(key) && GetKeyEvent(key) > 0)
        {
            return true;
        }

        return false;
    }

    public static void SendKey(int keyEvent) {
        Execute(KeyUtils::Init, !initialized);
        Log("Key Sent, three!");
        robot.keyPress(keyEvent);
        robot.keyRelease(keyEvent);
        Log("Pressing: " + keyEvent);

    }

    public static void SendKey(String keyName) {
        Execute(KeyUtils::Init, !initialized);
        Log("Key Sent, One!");
        Integer keyEvent = GetRobotKeyEvent(keyName.toUpperCase());
        if (keyEvent != null) {

            Log("Key Sent, Two!");
            SendKey(keyEvent);
        } else {
            System.err.println("Key name not found: " + keyName);
        }
    }

    public static void HoldKeyDownFor(int keyCode, long duration)
    {
        robot.keyPress(keyCode);
        Sleep(duration);
        robot.keyRelease(keyCode);
    }

    public static void SendEnter() {
        Robot robot;
        try {
            robot = new Robot();
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public static void SendBackspace() {

        robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);

    }

    public static void SubscribeKeyEvent(Runnable method, String key_) {
        Execute(KeyUtils::Init, !initialized);
        int toInt = GetKeyEvent(key_);
        if (!inputs.contains(toInt)) {
            inputs.add(toInt);
            //Log("Key Event Added! Int: " + toInt);
        }
        if (!processes.contains(method)) {
            processes.add(method);
        }
    }


    public static void SubscribeKeyEvent(Runnable method, int key_) {
        Execute(KeyUtils::Init, !initialized);
        inputs.add(key_);
        //Log("Key Event Added! Int: " + key_);

        if (!processes.contains(method)) {
            processes.add(method);
        }
    }

    public static void SubscribeKeyScript(String key, String script) {
        Execute(KeyUtils::Init, !initialized);
        if (!scriptKeys.contains(key)) {
            scriptKeys.add(key);
            //Log("Key Event Added! Int: " + key);
        }
        if (!scripts.contains(script)) {
            scripts.add(script);
        }
    }

    @Override
    public void nativeKeyPressed(NativeKeyEvent e) {

    }

    @Override
    public void nativeKeyReleased(NativeKeyEvent e) {

        int vkCode = e.getKeyCode();

       /* lastPressed = vkCode;
        keyPressed = true;

        coroutine.Resume();*/

        for(int i = 0; i < inputs.size(); i++)
        {
            if(inputs.get(i) == vkCode)
            {
                processes.get(i).run();
            }
        }

    }

    @Override
    public void nativeKeyTyped(NativeKeyEvent e) {
        // Optional: Handle key typed event if needed
    }

    private static Integer GetRobotKeyEvent(String keyName) {
        switch (keyName) {
            case "F5": return KeyEvent.VK_F5;
            case "F7": return KeyEvent.VK_F7;
            case "F1": return KeyEvent.VK_F1;
            case "F4": return KeyEvent.VK_F4;
            case "F3": return KeyEvent.VK_F3;
            case "H": return KeyEvent.VK_H;
            case "O": return KeyEvent.VK_O;
            case "M": return KeyEvent.VK_M;
            case "E": return KeyEvent.VK_E;
            case "!": return KeyEvent.VK_EXCLAMATION_MARK;
        }
        return 0;
    }

    public static Integer GetKeyEvent(String keyName) {
        switch (keyName) {
            case "F5": return NativeKeyEvent.VC_F5;
            case "F7": return NativeKeyEvent.VC_F7;
            case "F1": return NativeKeyEvent.VC_F1;
            case "F4": return NativeKeyEvent.VC_F4;
            case "F3": return NativeKeyEvent.VC_F3;

            case "1":
                return NativeKeyEvent.VC_1;
            case "2":
                return NativeKeyEvent.VC_2;
            case "3":
                return NativeKeyEvent.VC_3;
            case "4":
                return NativeKeyEvent.VC_4;
            case "A":
                return NativeKeyEvent.VC_A;
            case "B":
                return NativeKeyEvent.VC_B;
            case "C":
                return NativeKeyEvent.VC_C;
            case "D":
                return NativeKeyEvent.VC_D;
            case "E":
                return NativeKeyEvent.VC_E;
            case "F":
                return NativeKeyEvent.VC_F;
            case "G":
                return NativeKeyEvent.VC_G;
            case "H":
                return NativeKeyEvent.VC_H;
            case "I":
                return NativeKeyEvent.VC_I;
            case "J":
                return NativeKeyEvent.VC_J;
            case "K":
                return NativeKeyEvent.VC_K;
            case "L":
                return NativeKeyEvent.VC_L;
            case "M":
                return NativeKeyEvent.VC_M;
            case "N":
                return NativeKeyEvent.VC_N;
            case "O":
                return NativeKeyEvent.VC_O;
            case "P":
                return NativeKeyEvent.VC_P;
            case "Q":
                return NativeKeyEvent.VC_Q;
            case "R":
                return NativeKeyEvent.VC_R;
            case "S":
                return NativeKeyEvent.VC_S;
            case "T":
                return NativeKeyEvent.VC_T;
            case "U":
                return NativeKeyEvent.VC_U;
            case "V":
                return NativeKeyEvent.VC_V;
            case "W":
                return NativeKeyEvent.VC_W;
            case "X":
                return NativeKeyEvent.VC_X;
            case "Y":
                return NativeKeyEvent.VC_Y;
            case "Z":
                return NativeKeyEvent.VC_Z;
            case "ENTER":
                return NativeKeyEvent.VC_ENTER;
            case "ESC":
                return NativeKeyEvent.VC_ESCAPE;
            case "SPACE":
                return NativeKeyEvent.VC_SPACE;
            case "CTRL":
                return NativeKeyEvent.VC_CONTROL;
            case "SHIFT":
                return NativeKeyEvent.VC_SHIFT;
            case "ALT":
                return NativeKeyEvent.VC_ALT;
            case "BACKSPACE":
                return NativeKeyEvent.VC_BACKSPACE; // Added backspace
            // Add more keys as needed
        }
        return 0;

    }
}