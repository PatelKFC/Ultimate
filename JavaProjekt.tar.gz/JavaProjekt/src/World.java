
public class World extends J
{
    public static final String COINS = Resources("grounditems/gold_coins");
    public static final String YAK = Resources("npcs/yak");
    public static final String FIRE_GIANT = Resources("npcs/fire_giant");

    public static ColorEntity GetArea(String line)
    {
        if(line.contains("Home"))
        {
            return DynamicValues.GetColor("Home");
        }

        return null;
    }

    public static String To3D(String id)
    {
        switch(id)
        {
            case "Coins":
                return COINS;

            case "gold_coins":
                return COINS;


            case "yak":
                return YAK;


            case "Yak":
                return YAK;

            case "fire_giant":
                return FIRE_GIANT;

            case "Fire_Giant":
                return FIRE_GIANT;

            case "FireGiant":
                return FIRE_GIANT;
        }

        return FIRE_GIANT;
    }
}