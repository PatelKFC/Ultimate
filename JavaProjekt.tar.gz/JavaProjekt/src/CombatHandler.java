import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


public class CombatHandler extends J
{
    public static BufferedImage healthBar;
    public static final String healthBarPath = Resources("sprites/in_combat.png");
    public static int xOffset = -200;
    public static int yOffset = -100;
    public static int radius = DynamicValues.GetValue("RADIUS");

    public static Point point;

    public static boolean inCombat;

    public static boolean initialized;

    public static Thread thread;


    public static void Init()
    {
        try {
            if(initialized) return;
            System.out.println("Initialized CombatHandler!");
            healthBar = ImageIO.read(new File(Resources("sprites/health_bar.png")));

            KeyUtils.SubscribeKeyEvent(CombatHandler::Test, "V");
            initialized = true;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void Test()
    {
        point = ScreenUtils.GetCenterPoint("RuneWild");

        point.x += xOffset;
        point.y += yOffset;

        //MouseUtils.MoveTo(point);
    }

    public static boolean InCombat()
    {
        Test();
        return ScreenUtils.HasColor("Healthbar", DynamicValues.GetValue("LOCAL_SEARCH_RADIUS"), point);
    }


}